package com.example.recyleview_v1

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.RecyclerView
import de.hdodenhof.circleimageview.CircleImageView

class CountryAdapter(
    var countryNameList: ArrayList<String>,
    var detailsList: ArrayList<String>,
    var imageList: ArrayList<Int>,
    var context: Context) : RecyclerView.Adapter<CountryAdapter.CountryViewHolder>() {

    class CountryViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            var textViewcountry : TextView = itemView.findViewById(R.id.textViewcountry)
            var textViewDetail : TextView = itemView.findViewById(R.id.textViewDetail)
            var ImageView : CircleImageView = itemView.findViewById(R.id.ImageView)
            var cardView : CardView = itemView.findViewById(R.id.cardView)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CountryViewHolder {
        val view : View = LayoutInflater.from(parent.context).inflate(R.layout.card_design,parent,false)

        return CountryViewHolder(view)
    }

    override fun getItemCount(): Int {

        return countryNameList.size
    }

    override fun onBindViewHolder(holder: CountryViewHolder, position: Int) {

        holder.textViewcountry.text = countryNameList.get(position)
        holder.textViewDetail.text = detailsList.get(position)
        holder.ImageView.setImageResource(imageList.get(position))
        holder.cardView.setOnClickListener {
            Toast.makeText(context,"This is the ${countryNameList.get(position)}",Toast.LENGTH_LONG).show()
        }

    }

}