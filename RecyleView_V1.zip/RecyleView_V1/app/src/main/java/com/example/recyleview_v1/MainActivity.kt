package com.example.recyleview_v1

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.RecyclerView.Recycler

class MainActivity : AppCompatActivity() {

    lateinit var recyclerview : RecyclerView

    var countryNameList = ArrayList<String>()
    var detailsList = ArrayList<String>()
    var imageList = ArrayList<Int>()

    lateinit var adapter: CountryAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerview = findViewById(R.id.recycleviewer)

        recyclerview.layoutManager = LinearLayoutManager(this@MainActivity)

        countryNameList.add("Philippines")
        countryNameList.add("United Kingdom")
        countryNameList.add("Vichy France")
        countryNameList.add("Germany")
        countryNameList.add("USA")
        countryNameList.add("Canada")
        countryNameList.add("China")
        countryNameList.add("Slovakia")
        countryNameList.add("Romania")
        countryNameList.add("Hungary")
        countryNameList.add("Japan")
        countryNameList.add("Luxemberg")
        countryNameList.add("USSR")


        detailsList.add("Rich in ocean welcome to the philippines")
        detailsList.add("The land of the kings and queens!")
        detailsList.add("We fight for our freedom")
        detailsList.add("The land of Machines")
        detailsList.add("Peace and Unification for it's lands")
        detailsList.add("Birch")
        detailsList.add("How to be rich")
        detailsList.add("Beauty and nature to be fulfilled")
        detailsList.add("Tate land")
        detailsList.add("Never leave neighbors behind")
        detailsList.add("The land of the rising sun")
        detailsList.add("Smallest")
        detailsList.add("Total Domination")

        imageList.add(R.drawable.ph)
        imageList.add(R.drawable.uk)
        imageList.add(R.drawable.vichy)
        imageList.add(R.drawable.germany)
        imageList.add(R.drawable.usa)
        imageList.add(R.drawable.canada)
        imageList.add(R.drawable.china)
        imageList.add(R.drawable.slovakia)
        imageList.add(R.drawable.romania)
        imageList.add(R.drawable.hungary)
        imageList.add(R.drawable.japan)
        imageList.add(R.drawable.luxemberg)
        imageList.add(R.drawable.ussr)

        adapter = CountryAdapter(countryNameList,detailsList,imageList,this@MainActivity)

        recyclerview.adapter = adapter
    }
}